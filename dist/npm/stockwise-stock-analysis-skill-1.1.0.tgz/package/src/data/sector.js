import { fetchJson } from '../utils/api.js';
import { round, safeNumber } from '../analysis/technical.js';
import { chinaDateString, chinaDateTimeString, parseEpochSeconds } from '../utils/china-time.js';

const SECTOR_FIELDS = [
  'f12', 'f14', 'f2', 'f3', 'f8', 'f62', 'f66', 'f69', 'f72', 'f75',
  'f104', 'f105', 'f106', 'f109', 'f124', 'f128', 'f136', 'f164',
].join(',');

export async function fetchRankedSectors(options = {}) {
  const type = options.type === 'concept' ? 'concept' : 'industry';
  const limit = options.limit ?? 20;
  const rows = await fetchEastmoneySectors(type, Math.max(limit, 30));
  const stats = await Promise.allSettled(rows.map((sector) => fetchSectorKlineStats(sector.code)));
  const withHistory = rows.map((sector, index) => {
    const result = stats[index];
    return result.status === 'fulfilled' ? { ...sector, ...result.value } : sector;
  });
  const enriched = withHistory.map((sector) => ({
    ...sector,
    rotation: detectSectorRotation(sector),
    heatScore: calculateSectorHeatScore(sector),
  }));

  const ranked = enriched
    .sort((a, b) => b.heatScore - a.heatScore)
    .slice(0, limit);

  const leaders = [...enriched].sort((a, b) => (b.changePct ?? -999) - (a.changePct ?? -999)).slice(0, 5);
  const laggards = [...enriched].sort((a, b) => (a.changePct ?? 999) - (b.changePct ?? 999)).slice(0, 5);
  const strong5d = enriched.filter((item) => (item.change5d ?? 0) > 3).slice(0, 5);
  const weak5d = enriched.filter((item) => (item.change5d ?? 0) < -3).slice(0, 5);
  const fundDivergence = enriched
    .filter((item) => (item.mainNetInflow ?? 0) > 0 && Math.abs(item.changePct ?? 0) < 0.5)
    .sort((a, b) => (b.mainNetInflow ?? 0) - (a.mainNetInflow ?? 0))
    .slice(0, 5);

  return {
    type,
    sectors: ranked,
    leaders,
    laggards,
    rotation: {
      strong5d,
      weak5d,
      fundDivergence,
    },
    dataTime: (() => {
      const latest = rows.map((item) => item.quoteTime).filter(Boolean).sort().at(-1);
      return latest ? chinaDateTimeString(new Date(latest)) : null;
    })(),
  };
}

async function fetchEastmoneySectors(type, limit) {
  const fs = type === 'concept' ? 'm:90+t:3+f:!50' : 'm:90+t:2+f:!50';
  const data = await fetchJson('https://push2.eastmoney.com/api/qt/clist/get', {
    params: {
      pn: 1,
      pz: limit,
      po: 1,
      np: 1,
      fltt: 2,
      invt: 2,
      fid: 'f3',
      fs,
      fields: SECTOR_FIELDS,
      ut: 'bd1d9ddb04089700cf9c27f6f7426281',
    },
  });
  const diff = data?.data?.diff;
  if (!Array.isArray(diff) || diff.length === 0) {
    throw new Error('无法获取东方财富板块数据');
  }
  return diff.map((item) => {
    const quoteTime = parseEpochSeconds(item.f124);
    return ({
    code: item.f12,
    name: item.f14,
    price: safeNumber(item.f2),
    changePct: safeNumber(item.f3),
    turnoverRate: safeNumber(item.f8),
    mainNetInflow: item.f62 == null ? null : round(safeNumber(item.f62) / 100000000, 2),
    superNetInflow: item.f66 == null ? null : round(safeNumber(item.f66) / 100000000, 2),
    riseCount: safeNumber(item.f104),
    fallCount: safeNumber(item.f105),
    flatCount: safeNumber(item.f106),
    change5d: safeNumber(item.f109),
    change20d: safeNumber(item.f164),
    leadingStock: item.f128 ?? item.f136 ?? '',
    quoteTime: quoteTime?.toISOString() ?? null,
    tradeDate: quoteTime ? chinaDateString(quoteTime) : null,
  });
  });
}

async function fetchSectorKlineStats(code) {
  const data = await fetchJson('https://push2his.eastmoney.com/api/qt/stock/kline/get', {
    params: {
      secid: `90.${code}`,
      klt: 101,
      fqt: 1,
      beg: '20200101',
      end: '20500101',
      lmt: 30,
      fields1: 'f1,f2,f3,f4,f5,f6',
      fields2: 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61',
    },
  });
  const klines = data?.data?.klines;
  if (!Array.isArray(klines) || klines.length < 6) throw new Error('板块 K 线不足');
  const rows = klines.map((line) => {
    const [date, open, close, high, low, volume] = String(line).split(',');
    return {
      date,
      open: safeNumber(open),
      close: safeNumber(close),
      high: safeNumber(high),
      low: safeNumber(low),
      volume: safeNumber(volume),
    };
  }).filter((row) => Number.isFinite(row.close));
  const latest = rows.at(-1);
  const previous5 = rows.at(-6);
  const previous20 = rows.at(-21);
  const avgVolume5 = rows.slice(-6, -1).reduce((sum, row) => sum + (row.volume ?? 0), 0) / Math.min(5, rows.length - 1);
  return {
    change5d: previous5 ? round((latest.close - previous5.close) / previous5.close * 100, 2) : null,
    change20d: previous20 ? round((latest.close - previous20.close) / previous20.close * 100, 2) : null,
    volumeRatio: avgVolume5 ? round((latest.volume ?? 0) / avgVolume5, 2) : null,
  };
}

/**
 * 使用公开组成项计算板块热度，返回值只用于横截面排序而非收益预测。
 */
export function calculateSectorHeatScore(sector) {
  const day = sector.changePct ?? 0;
  const five = sector.change5d ?? day;
  const twenty = sector.change20d ?? five;
  const fund = sector.mainNetInflow ?? 0;
  const turnover = sector.turnoverRate ?? 0;
  return round(
    day * 0.35
      + five * 0.25
      + twenty * 0.15
      + Math.sign(fund) * Math.min(Math.abs(fund), 30) * 0.15
      + turnover * 0.1,
    4,
  );
}

function detectSectorRotation(sector) {
  const signals = [];
  if ((sector.changePct ?? 0) > 1.5 && (sector.change5d ?? 0) > 3) {
    signals.push('连续走强');
  }
  if ((sector.changePct ?? 0) < -1.5 && (sector.change5d ?? 0) < -3) {
    signals.push('连续走弱');
  }
  if ((sector.mainNetInflow ?? 0) > 0 && Math.abs(sector.changePct ?? 0) < 0.5) {
    signals.push('资金流入但价格滞涨');
  }
  if ((sector.mainNetInflow ?? 0) < 0 && (sector.changePct ?? 0) > 1) {
    signals.push('上涨但资金流出');
  }
  return signals.length ? signals.join(' / ') : '正常';
}
