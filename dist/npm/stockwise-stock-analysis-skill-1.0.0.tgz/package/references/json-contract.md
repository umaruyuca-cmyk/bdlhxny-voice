# JSON 契约

后台系统必须给真实 Command 添加 `--json`，并且只解析 stdout。stderr 仅用于诊断。

四个 Command 共用以下顶层字段：

```json
{
  "schemaVersion": "1.0",
  "command": "stock|portfolio|quant|sector",
  "timezone": "Asia/Shanghai",
  "asOf": "已核验的市场数据时间",
  "request": {},
  "dataQuality": {
    "status": "verified|limited|unknown",
    "asOf": "已核验的市场数据时间",
    "allowsDirectionalSignal": false,
    "provisional": false,
    "warnings": []
  },
  "data": {},
  "sources": {}
}
```

规则：

- stdout 只能包含一个 UTF-8 JSON 文档。
- `asOf` 必须来自行情、K线、净值或板块数据。
- 调用方必须同时校验 `schemaVersion`、`command`、`asOf` 和 `dataQuality`。
- 禁止把文本看板包装成成功 JSON。
- 失败使用非零退出码，stderr 返回：

```json
{
  "schemaVersion": "1.0",
  "command": "portfolio",
  "timezone": "Asia/Shanghai",
  "asOf": null,
  "error": {
    "code": "PORTFOLIO_CONFIG_NOT_FOUND",
    "message": "真实持仓配置文件不存在"
  }
}
```
