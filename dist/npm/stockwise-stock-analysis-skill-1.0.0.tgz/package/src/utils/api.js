import axios from 'axios';
import { DEFAULTS } from '../config.js';
import { logSourceFailure } from './logger.js';

export const http = axios.create({
  timeout: DEFAULTS.requestTimeoutMs,
  headers: {
    Accept: '*/*',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125 Safari/537.36',
    Referer: 'https://finance.eastmoney.com/',
  },
});

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function requestWithRetry(config, options = {}) {
  const retries = options.retries ?? DEFAULTS.retries;
  let lastError;

  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      return await http.request(config);
    } catch (error) {
      lastError = error;
      if (attempt < retries) {
        await sleep(250 * 2 ** (attempt - 1));
      }
    }
  }

  throw lastError;
}

export async function fetchJson(url, options = {}) {
  const response = await requestWithRetry({
    url,
    method: 'GET',
    params: options.params,
    responseType: 'json',
    timeout: options.timeout ?? DEFAULTS.requestTimeoutMs,
    headers: options.headers,
  }, options);
  return response.data;
}

export async function fetchText(url, options = {}) {
  const response = await requestWithRetry({
    url,
    method: 'GET',
    params: options.params,
    responseType: options.responseType ?? 'text',
    timeout: options.timeout ?? DEFAULTS.requestTimeoutMs,
    headers: options.headers,
  }, options);

  if (options.encoding && response.data instanceof ArrayBuffer) {
    return new TextDecoder(options.encoding).decode(response.data);
  }
  if (Buffer.isBuffer(response.data) && options.encoding) {
    return new TextDecoder(options.encoding).decode(response.data);
  }
  return response.data;
}

export async function tryDataSources(sources, context = {}) {
  const errors = [];
  for (const source of sources) {
    try {
      const result = await source.fetch();
      if (result == null) {
        throw new Error('返回空数据');
      }
      return { ...result, source: result.source ?? source.name };
    } catch (error) {
      errors.push(`${source.name}: ${error.message}`);
      logSourceFailure(source.name, error, context.verbose);
    }
  }

  const subject = context.subject ?? '数据';
  throw new Error(`无法获取 ${subject}: 已尝试 ${sources.length} 个数据源 (${errors.join('; ')})`);
}

export function unwrapEastmoneyJsonp(payload) {
  if (typeof payload !== 'string') {
    return payload;
  }
  const match = payload.match(/^[^(]*\((.*)\);?$/s);
  return JSON.parse(match ? match[1] : payload);
}
