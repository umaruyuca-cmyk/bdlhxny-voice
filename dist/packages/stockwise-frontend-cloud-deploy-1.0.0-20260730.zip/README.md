# StockWise Frontend

独立 Nginx 静态前端。正式页面通过同源 `/api/` 调用监听在 `127.0.0.1:8081` 的 StockWise Backend。

## 测试

```bash
npm test
```

## 构建和启动

在本目录执行：

```bash
docker build -t stockwise-frontend:1.0.0 .

docker run -d \
  --name stockwise-frontend \
  --restart unless-stopped \
  --network host \
  stockwise-frontend:1.0.0
```

访问：

```text
http://118.25.178.86:8082/
```

更新前端时只需要重新构建和替换 `stockwise-frontend` 容器，不需要重新打包或重启 Backend JAR。
