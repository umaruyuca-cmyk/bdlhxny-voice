import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

/**
 * 验证正式页面使用POST流式协议且不再把消息或用户ID放进URL。
 */
test("正式页面使用同源POST流并遵守身份边界", async () => {
  const html = await readFile(
    new URL("../public/stockwise-chat.html", import.meta.url),
    "utf8",
  );

  assert.match(html, /fetch\(\"\/api\/v1\/chat\/stream\"/);
  assert.match(html, /method:\"POST\"/);
  assert.match(html, /response\.body\.getReader\(\)/);
  assert.doesNotMatch(html, /new EventSource\(/);
  assert.doesNotMatch(html, /chat\/stream\?userId=/);
  assert.doesNotMatch(html, /agent-runs\?userId=/);
  assert.match(html, /fetch\(\"\/api\/v1\/knowledge\?limit=50\"/);
  assert.match(html, /fetch\(\"\/api\/v1\/agent-runs\?limit=20\"/);
});
